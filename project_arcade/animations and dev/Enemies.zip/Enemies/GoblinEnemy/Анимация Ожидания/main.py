import arcade

class Goblin(arcade.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.scale = 2.0

        self.idle_textures = []
        texture = arcade.load_texture("IdleGoblin.png")
        width = texture.width // 4
        height = texture.height
        for i in range(4):
            frame = texture.crop(
                x=i * width, y=0, width=width, height=height
            )
            self.idle_textures.append(frame)

        self.texture = self.idle_textures[0]
        self.current_texture = 0
        self.delta_time_sum = 0
        self.animation_speed = 0.25

        self.center_x = x
        self.center_y = y

    def update_animation_skeleton(self, delta_time):
        self.delta_time_sum += delta_time
        if self.delta_time_sum >= self.animation_speed:
            self.delta_time_sum = 0
            self.current_texture = (
                self.current_texture + 1
            ) % len(self.idle_textures)
            self.texture = self.idle_textures[self.current_texture]

    def update_skeleton(self, delta_time):
        self.update_animation(delta_time)



